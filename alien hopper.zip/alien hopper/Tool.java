
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;


/**
 * @author group 9
 * @create 2020-05
 */
public class Tool {
    /**
     * handle with situation where multiple aliens at same position
     * @param aliens all aliens in program
     * @param thisAlien aliens on move,now he has been in a new position
     * @return
     */
    public static void samePositon(Alien[] aliens, Alien thisAlien, 
    Map<Alien, ImageIcon>lastIcon,List<JLabel>positons,
    Map<JLabel, List<Alien>>coexist) {
        Alien sameUserAlien = null;
        List<Alien> anotherUserAliens = new ArrayList<>();

        for (Alien alien:aliens){
            if(alien.getNumber() != thisAlien.getNumber()){//other aliens
                if(alien.getUserOrder()== (thisAlien.getUserOrder())){
                    sameUserAlien = alien;
                }else {
                    anotherUserAliens.add(alien);
                }
            }
        }
        //if two aliens of current user at same position,position not change
        if(sameUserAlien.getPositionName().equals(thisAlien.getPositionName())){
            return ;
        }else {
            //if two aliens of the other user at same position,
            //position not change
            if(anotherUserAliens.get(0).getPositionName().equals(anotherUserAliens.get(1).getPositionName()) ){
                return ;
            }else{
                //If alien from another user at same position as the current user,
                //then it will be sent to 50
                for(Alien alien : anotherUserAliens){
                    if(alien.getPositionName().equals(thisAlien.getPositionName()) ){
//                  alien.setPositionName("50");
//                  lastIcon.put(alien, (ImageIcon)alien.getStartPos().getIcon());
//                  alien.getStartPos().setIcon(alien.getIcon());
//                  System.out.println("xiangtongweizhi");
                    	moveTo(alien, "50", lastIcon,  positons, coexist);
                    }
                }
                return ;
            }
        }
    }

    //user choose aliens
    //then create array user and alien
    public static User chooseAlien(String userName, String userAliensName, JLabel[] aliens, int userOrder){
            User user = new User(userName);
            String name1 = userAliensName.split(";")[0];
            String name2 = userAliensName.split(";")[1];
            int number1 = Integer.parseInt(name1.substring(name1.length() - 1));
            int number2 = Integer.parseInt(name2.substring(name2.length()  - 1));
            ImageIcon icon1 = new ImageIcon();
            ImageIcon icon2 = new ImageIcon();
            
            //set image for every alien
            for(JLabel label : aliens) {
            	if(label.getText().equals(name1)) {
            		icon1 = (ImageIcon)label.getIcon();
            	}
            	if(label.getText().equals(name2)) {
            		icon2 = (ImageIcon)label.getIcon();
            	}
            }
            
            Alien alien1 = new Alien(userOrder, number1, icon1);
            Alien alien2 = new Alien(userOrder, number2, icon2);
            user.setAliens(alien1);
            user.setAliens(alien2);
            return user;
        }
    
    //judge move direction,add or sub number
    public static boolean moveBack(JLabel posLabel)
	{
    	//get number of current position
    	String posName = posLabel.getText();
    	int pos = Integer.parseInt(posName);
    	if(pos >= 11 && pos <= 19) {
    		return false;
    	}else {
    		return true;
    	}
	}
    
    //get corresponding Label according to its name
    public static JLabel findPosLabel(String posName, List<JLabel> positons)
	{
    	for(JLabel pos : positons) {
    		if(pos.getText().equals(posName)) {
    			return pos;
    		}
    	}
		return null;
	}
    
    //after move...
    /**
     * 
     * @param moveAlien the current moving alien
     * @param lastIcon last position image of every alien
     * @param positons	position in map--array Label 
     * @param aliens aliens joined game
     * @param dark
     * @return
     */
    public static Alien check(Alien moveAlien, Map<Alien, ImageIcon>lastIcon, List<JLabel>positons, Alien[] gameAliens, Map<Alien,Integer>dark,Map<JLabel, List<Alien>>coexist) {
    	int nowPos = Integer.parseInt(moveAlien.getPositionName());
    	if(nowPos == 45 || nowPos == 43 || nowPos == 33 || nowPos == 24) {//safe cloud
    		return moveAlien;
    	}
    	
    	//firstly judge whether have alien at same cloud
    	samePositon(gameAliens, moveAlien, lastIcon, positons, coexist);
    	
    	switch (nowPos)
		{
		case 47: moveAlien = moveTo(moveAlien,"42",lastIcon,positons,coexist);
			break;
			
		case 38: moveAlien = moveTo(moveAlien, "31", lastIcon, positons,coexist);
			break;
			
		case 30: moveAlien = moveTo(moveAlien, "25", lastIcon, positons,coexist);
			break;
		
		case 26: moveAlien = moveTo(moveAlien, "21", lastIcon, positons,coexist);
			break;
		
		case 35: 
		
		case 31: dark.put(moveAlien, 2);
			break;
			
		case 40:
		
		case 29: moveAlien = moveTo(moveAlien, "50", lastIcon, positons,coexist);
			break;
		default:
			break;
		}
    	
    	return moveAlien;
    }
    
    public static Alien  moveTo(Alien moveAlien, String dest, Map<Alien, ImageIcon>lastIcon, List<JLabel>positons,Map<JLabel, List<Alien>>coexist) {
    	
    	Border border1 = new LineBorder(Color.BLUE, 4);
    	Border border2 = new LineBorder(Color.WHITE, 2);
    	Border border3 = new LineBorder(Color.RED,3);
    	
    	
    	//restore current icon
    	//Label of now cloud
    	JLabel nowLabel;
    	//since the above 4 are same,we cannot take positonName as current cloud
    	if(moveAlien.getPositionName().equals("50")) {
    		nowLabel = moveAlien.getStartPos();
    		nowLabel.setBorder(border1);
    		System.out.println("return" + nowLabel);
    	}else {
    		nowLabel = findPosLabel(moveAlien.getPositionName(), positons);
    		nowLabel.setBorder(border2);
		}
    		
    	for(int i = 0; i < coexist.get(nowLabel).size(); i++) {//remove the moving alien from current cloud
    		if(coexist.get(nowLabel).get(i) == moveAlien) {
    			coexist.get(nowLabel).remove(i);
    		}
    	}
    	if(coexist.get(nowLabel).size() > 0) {//if there is other aliens,shoe icon of 1st alien
    		nowLabel.setIcon(coexist.get(nowLabel).get(coexist.get(nowLabel).size() - 1).getIcon());
    	}else {//there is no alien
    		nowLabel.setIcon(lastIcon.get(moveAlien));
		}
    	
    	
    	
    	//obtain next cloud
    	moveAlien.setPositionName(dest);
    	JLabel destLable;
    	if(dest.equals("50")) {
    		destLable = moveAlien.getStartPos();
    	}else {
    		destLable = Tool.findPosLabel(dest, positons);
    	}
    	
    	//store next cloud icon,consider whether there is alien on next cloud
    	if(coexist.get(destLable).size() > 0) {//there is alien on next cloud,take lastIcon of 1st alien here as icon
    		lastIcon.put(moveAlien,lastIcon.get(coexist.get(destLable).get(0)));
    	}else {
    		lastIcon.put(moveAlien, (ImageIcon)destLable.getIcon());
		}
    	
    	//move to next cloud
    	destLable.setIcon(moveAlien.getIcon());
    	coexist.get(destLable).add(moveAlien);
    	destLable.setBorder(border3);
    	System.out.println(destLable.getText() + "icon" + destLable.getIcon());
//    	for(Alien alien : lastIcon.keySet()) {
//    		System.out.println("zhezhialien" + alien.getIcon());
//    	}
    	
    	return moveAlien;
    }
    
 public static void safePosCheck(Alien moveAlien, Integer pos, Map<Integer, List<Alien>> safePos) {
    	
	 
    }
 
 
   
}



