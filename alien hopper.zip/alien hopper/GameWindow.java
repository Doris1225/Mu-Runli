
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;


import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

public class GameWindow
{

    private JFrame frame;
    private JFrame secondFrame;
    private JTextField user1name;
    private JTextField alienOfUser1names;
    private JTextField user2name;
    private JTextField alienOfUser2Names;
    private boolean isChoose1 = false;
    private boolean isChoose2 = false;
    private static GameWindow window = new GameWindow();
    
    private  User[] users = new User[2];
    private  Alien[] gameAliens = new Alien[4];

    /**
     * Launch the application.
     */
    public static void main(String[] args)
    {
        EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                try
                {
                    window.frame.setVisible(true);
                  
                } catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        });
        
        
    }

    /**
     * Create the application.
     * @wbp.parser.entryPoint
     */
    public GameWindow()
    {
        initialize();
        
        
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize()
    {
    	
        frame = new JFrame("game");
        frame.setBounds(100, 100, 808, 504);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JPanel panel = new JPanel();
        panel.setBounds(14, 13, 776, 59);
        frame.getContentPane().add(panel);

        JLabel alien1 = new JLabel("alien1");
        alien1.setIcon(new ImageIcon("image\\alien1.png"));
        panel.add(alien1);

        JLabel alien2 = new JLabel("alien2");
        alien2.setIcon(new ImageIcon("image\\alien2.png"));
        panel.add(alien2);

        JLabel alien3 = new JLabel("alien3");
        alien3.setIcon(new ImageIcon("image\\alien3.png"));
        panel.add(alien3);

        JLabel alien4 = new JLabel("alien4");
        alien4.setIcon(new ImageIcon("image\\alien4.png"));
        panel.add(alien4);

        JLabel alien5 = new JLabel("alien5");
        alien5.setIcon(new ImageIcon("image\\alien5.png"));
        panel.add(alien5);

        JLabel alien6 = new JLabel("alien6");
        alien6.setIcon(new ImageIcon("image\\alien6.png"));
        panel.add(alien6);

        JLabel alien7 = new JLabel("alien7");
        alien7.setIcon(new ImageIcon("image\\alien7.png"));
        panel.add(alien7);

        JLabel alien8 = new JLabel("alien8");
        alien8.setIcon(new ImageIcon("image\\alien8.png"));
        panel.add(alien8);

        JLabel[] aliens = new JLabel[8];
        aliens[0] = alien1;
        aliens[1] = alien2;
        aliens[2] = alien3;
        aliens[3] = alien4;
        aliens[4] = alien5;
        aliens[5] = alien6;
        aliens[6] = alien7;
        aliens[7] = alien8;

        Border border = new LineBorder(Color.BLUE, 4);
        for(JLabel label : aliens) {
            label.setBorder(border);
        }

        JPanel user1 = new JPanel();
        user1.setBounds(0, 282, 363, 162);
        frame.getContentPane().add(user1);
        user1.setLayout(null);

        JLabel user1Name = new JLabel("user1name");
        user1Name.setBounds(14, 13, 137, 18);
        user1.add(user1Name);

        user1name = new JTextField();
        user1name.setBounds(190, 10, 103, 24);
        user1.add(user1name);
        user1name.setColumns(10);

        JLabel alienOfUser1Name = new JLabel("user1'alien name");
        alienOfUser1Name.setBounds(14, 67, 137, 18);
        user1.add(alienOfUser1Name);

        alienOfUser1names = new JTextField();
        alienOfUser1names.setBounds(190, 64, 103, 24);
        user1.add(alienOfUser1names);
        alienOfUser1names.setColumns(10);

        //user1 choose aliens
        JButton choose1 = new JButton("user1 choose");
        choose1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent arg0) {
                
                //initialise inputText as empty 
                alienOfUser1names.setText("");
                
                //avoid repeat of adding label's MouseListener
                if(!isChoose1) {
                	isChoose1 = true;
                	for(JLabel alien : aliens) {
                        System.out.println(alien.getText());
//                        alien.getListeners().
                        alien.addMouseListener(new MouseAdapter() {
                            public void mouseClicked(MouseEvent argo) {
                            	//if input text available,that is user1's aliens not determined
                            	if(alienOfUser1names.isEditable()) {
                            		 //there is no ';' before second chosen alien 
                                    if(alienOfUser1names.getText().equals("")){
                                        alienOfUser1names.setText(alien.getText());
                                    }else{
                                        alienOfUser1names.setText(alienOfUser1names.getText() + ";" + alien.getText());
                                    }
                                    
                                    //set this label as not accessible
                                    alien.setEnabled(false);
                            	}
                            }
                        });
                    }
                }
                
            }
        });
        choose1.setBounds(14, 122, 113, 27);
        user1.add(choose1);

        //user1 determine alien
        JButton conform1 = new JButton("OK");
        conform1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String alienNames = alienOfUser1names.getText();
                String[] names = alienNames.split(";");
                if(names.length > 1) {
                    String name1 = names[names.length - 1];
                    String name2 = names[names.length - 2];
                    int number1 = Integer.parseInt(name1.substring(name1.length() - 1));
                    int number2 = Integer.parseInt(name2.substring(name2.length()  - 1));

                    //set first user and first 2 aliens
                    users[0] = Tool.chooseAlien(user1name.getText(), alienNames, aliens,1);
                    gameAliens[0] = users[0].getAliens().get(0);
                    gameAliens[1] = users[0].getAliens().get(1);
                    
                    
                    //set ailennames textfield as not accessible
                    alienOfUser1names.setEditable(false);
                    
                }
            }
        });
        conform1.setBounds(207, 122, 74, 27);
        user1.add(conform1);

        JPanel panel_1 = new JPanel();
        panel_1.setBounds(406, 282, 384, 162);
        frame.getContentPane().add(panel_1);
        panel_1.setLayout(null);

        JLabel lblUsername = new JLabel("user2name");
        lblUsername.setBounds(14, 13, 72, 18);
        panel_1.add(lblUsername);

        user2name = new JTextField();
        user2name.setColumns(10);
        user2name.setBounds(186, 10, 103, 24);
        panel_1.add(user2name);

        JLabel lblUseralienName = new JLabel("user2'alien name");
        lblUseralienName.setBounds(14, 70, 137, 18);
        panel_1.add(lblUseralienName);

        alienOfUser2Names = new JTextField();
        alienOfUser2Names.setColumns(10);
        alienOfUser2Names.setBounds(186, 67, 103, 24);
        panel_1.add(alienOfUser2Names);

        JButton choose2 = new JButton("user2 choose");
        choose2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent arg0) {
                //initialise inputText as empty 
                alienOfUser2Names.setText("");
                
                //avoid repeat of adding label's MouseListener
                if(!isChoose2) {
                	isChoose2 = true;
                	
                	for(JLabel alien : aliens) {
                        alien.addMouseListener(new MouseAdapter() {
                            public void mouseClicked(MouseEvent argo) {
                            	if(alienOfUser2Names.isEditable()) {
                            		//there is no ';' before second chosen alien 
                                    if(alienOfUser2Names.getText().equals("")){
                                        alienOfUser2Names.setText(alien.getText());
                                    }else{
                                        alienOfUser2Names.setText(alienOfUser2Names.getText() + ";" + alien.getText());
                                    }
                                  //set this label as not accessible
                                    alien.setEnabled(false);
                            	}
                            }
                        });
                    }
                }
                
                
            }
        });
        choose2.setBounds(14, 122, 113, 27);
        panel_1.add(choose2);

        JButton conform2 = new JButton("OK");
        conform2.setBounds(206, 122, 74, 27);
        conform2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String alienNames = alienOfUser2Names.getText();
                String[] names = alienNames.split(";");
                if(names.length > 1) {
                    String name1 = names[names.length - 1];
                    String name2 = names[names.length - 2];
                   
                    //set 2nd user and last 2 aliens
                    users[1] = Tool.chooseAlien(user2name.getText(), alienNames, aliens,2);
                    gameAliens[2] = users[1].getAliens().get(0);
                    gameAliens[3] = users[1].getAliens().get(1);
                    
                    //set ailennames textfield as not accessible
                    alienOfUser2Names.setEditable(false);
                    System.out.println("diyige:" + users[0].getName());
                    System.out.println("dierge:" + users[1].getName());
                }
            }
        });
        panel_1.add(conform2);
        
        //button for playing game
        JButton btnPlay = new JButton("play");
        btnPlay.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		window.frame.setVisible(false);
        		SecondFrame.users = users;
        		SecondFrame.gameAliens = gameAliens;
        		System.out.println("---------------------------alien who join game");
        		for(int i = 0; i < 4; i++) {
        			System.out.println(gameAliens[i].getIcon());
        			
        		}
        		System.out.println("1st user" + users[0].getName());
        		System.out.println("2nd user" + users[1].getName());
        		secondFrame = new SecondFrame("game");
                window.secondFrame.setVisible(true);
                
        	}
        });
        btnPlay.setOpaque(false);
        btnPlay.setIcon(new ImageIcon("image\\Play.png"));
        btnPlay.setBounds(339, 166, 134, 41);
        frame.getContentPane().add(btnPlay);
        
    }
}
