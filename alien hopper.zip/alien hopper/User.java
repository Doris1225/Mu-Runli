
import java.util.ArrayList;
import java.util.List;

/**
 * @author group 9
 * @create 2020-05
 */
public class User {
    private String name;
    private List<Alien> aliens = new ArrayList<>();
    public User(){}

    public User(String name){
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Alien> getAliens() {
        return aliens;
    }

    public void setAliens(Alien alien) {
        this.aliens.add(alien);
    }
}
