
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 * @author group 9
 * @create 2020-05
 */
public class Alien {
    private int userOrder;
    private ImageIcon icon;
    private String positionName;
    private JLabel startPos;
    public JLabel getStartPos()
	{
		return startPos;
	}
	public void setStartPos(JLabel startPos)
	{
		this.startPos = startPos;
	}
	private int number ;


    public Alien(){}
    public Alien(Integer  userOrder, int number, ImageIcon icon) {
        this.userOrder = userOrder;
        this.number = number;
        this.icon = icon;
        
        //set alien start position as 50
        this.positionName = "50";
    }
	
	public int getUserOrder()
	{
		return userOrder;
	}
	public void setUserOrder(int userOrder)
	{
		this.userOrder = userOrder;
	}
	public ImageIcon getIcon()
	{
		return icon;
	}
	public void setIcon(ImageIcon icon)
	{
		this.icon = icon;
	}
	public String getPositionName()
	{
		return positionName;
	}
	public void setPositionName(String positionName)
	{
		this.positionName = positionName;
	}
	public int getNumber()
	{
		return number;
	}
	public void setNumber(int number)
	{
		this.number = number;
	}

}
