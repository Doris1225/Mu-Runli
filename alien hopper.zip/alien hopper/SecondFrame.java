import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;



public class SecondFrame extends JFrame
{
	public String ziduan;
	
	public static User[] users = new User[2];
	public  static Alien[] gameAliens = new Alien[4];
	
	//whether roll the dice
	public static boolean isRoll = true;
	
	//which user in turn
	public static int turn = 1;
	
	//score of dice
	public static int score = 0;
	
	//realScore of move
	public static int realScore = 0;
	
	//record the icon covered when alien move into one cloud,in order to recover
	public static Map<Alien, ImageIcon> lastIcon = new HashMap<Alien, ImageIcon>();
	
	//record situation of an alien(cannot move,whether frozen,key is alien's number,
	//value is alien's state,0 normal,2 frozen
	public static Map<Alien, Integer> dark = new HashMap<>();
	
	//record 4 start point,in order to return
	public static JLabel[] startLables = new JLabel[4];
	
	//the alien be chosen to move 
	public static Alien moveAlien;
	
	//JLabel to store all position
	public static List<JLabel> positons = new ArrayList<JLabel>();
	
	//on certain cloud,there can be multiple alien
	public static Map<JLabel, List<Alien>>coexist = new HashMap<>();
	public static JTextField textField;
	public static JTextField textField_1;
	public static JTextField textField_2;
	public static JTextArea user1Tril;
	public static JTextArea user2Tril;
	
	
	public SecondFrame(String title)
	{
		super(title);
		setBounds(100, 100, 860, 732);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		
		JPanel panel = new JPanel(); 
				
		panel.setBounds(0, 13, 646, 40);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel label11 = new JLabel("50");
		label11.setBounds(86, 5, 75, 32);
		panel.add(label11);
		startLables[0] = label11;
		
		JLabel label12 = new JLabel("50");
		label12.setBounds(187, 5, 75, 32);
		panel.add(label12);
		startLables[1] = label12;
		
		JLabel midFillLabel = new JLabel("");
		midFillLabel.setBounds(323, 14, 0, 0);
		panel.add(midFillLabel);
		
		
		JLabel label21 = new JLabel("50");
		label21.setBounds(366, 5, 75, 32);
		panel.add(label21);
		startLables[2] = label21;
				
		JLabel label22 = new JLabel("50");
		label22.setBounds(472, 5, 75, 32);
		panel.add(label22);
		startLables[3] = label22;
		
		Border border = new LineBorder(Color.BLUE, 4);
		label11.setBorder(border);
		label12.setBorder(border);
		label21.setBorder(border);
		label22.setBorder(border);
		
		JPanel panel_1 = new JPanel(){
			@Override
			public void paint(Graphics g)
			{
				super.paint(g);
				g.drawLine(544,42,544,100);
				g.drawLine(552,42,552,100);
				
				g.drawLine(190,209,190,260);
				g.drawLine(198,209,198,260);
				
				g.drawLine(361,289,361,347);
				g.drawLine(369,289,369,347);
				
				g.drawLine(99,330,99,392);
				g.drawLine(107,330,107,392);
				
				
			}
		};	
		panel_1.setBackground(UIManager.getColor("Button.background"));
		panel_1.setBorder(new LineBorder(Color.RED));
		panel_1.setBounds(0, 62, 589, 656);
		getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		
		positons.add(label11);
		positons.add(label12);
		positons.add(label21);
		positons.add(label22);
		
		
		Border border2 = new LineBorder(Color.white, 2);
		JLabel lblNewLabel = new JLabel("49");
		lblNewLabel.setIcon(new ImageIcon("image\\Sample Normal Cloud.png"));
		lblNewLabel.setBounds(166, 13, 56, 29);
		lblNewLabel.setBorder(border2);
		panel_1.add(lblNewLabel);
		positons.add(lblNewLabel);
		
		JLabel label = new JLabel("48");
		label.setIcon(new ImageIcon("image\\Sample Normal Cloud.png"));
		label.setBounds(337, 13, 56, 29);
		label.setBorder(border2);
		panel_1.add(label);
		positons.add(label);
		
		JLabel label_1 = new JLabel("47");
		label_1.setIcon(new ImageIcon("image\\Sample Rain Cloud Icon .png"));
		label_1.setBounds(520, 13, 56, 29);
		label_1.setBorder(border2);
		panel_1.add(label_1);
		positons.add(label_1);
		 
		JLabel label_2 = new JLabel("45");
		label_2.setIcon(new ImageIcon("image\\Sample Safe Cloud Icon.png"));
		label_2.setBounds(75, 60, 56, 29);
		label_2.setBorder(border2);
		panel_1.add(label_2);
		positons.add(label_2);
		
		JLabel label_3 = new JLabel("46");
		label_3.setIcon(new ImageIcon("image\\Sample Normal Cloud.png"));
		label_3.setBounds(257, 60, 56, 29);
		label_3.setBorder(border2);
		panel_1.add(label_3);
		positons.add(label_3);
		
		JLabel label_4 = new JLabel("44");
		label_4.setIcon(new ImageIcon("image\\Sample Normal Cloud.png"));
		label_4.setBounds(426, 60, 56, 29);
		label_4.setBorder(border2);
		panel_1.add(label_4);
		positons.add(label_4);
		
		
		JLabel label_5 = new JLabel("41");
		label_5.setIcon(new ImageIcon("image\\Sample Normal Cloud.png"));
		label_5.setBounds(166, 100, 56, 29);
		label_5.setBorder(border2);
		panel_1.add(label_5);
		positons.add(label_5);
		
		JLabel label_6 = new JLabel("43");
		label_6.setIcon(new ImageIcon("image\\Sample Safe Cloud Icon.png"));
		label_6.setBounds(337, 100, 56, 29);
		label_6.setBorder(border2);
		panel_1.add(label_6);
		positons.add(label_6);
		
		JLabel label_7 = new JLabel("42");
		label_7.setIcon(new ImageIcon("image\\Sample Normal Cloud.png"));
		label_7.setBounds(520, 100, 56, 29);
		label_7.setBorder(border2);
		panel_1.add(label_7);
		positons.add(label_7);
		
		JLabel label_8 = new JLabel("40");
		label_8.setIcon(new ImageIcon("image\\cloud-lighting.png"));
		label_8.setBounds(75, 140, 56, 29);
		label_8.setBorder(border2);
		panel_1.add(label_8);
		positons.add(label_8);
		
		JLabel label_9 = new JLabel("38");
		label_9.setIcon(new ImageIcon("image\\Sample Rain Cloud Icon .png"));
		label_9.setBounds(166, 180, 56, 29);
		label_9.setBorder(border2);
		panel_1.add(label_9);
		positons.add(label_9);
		
		JLabel label_10 = new JLabel("34");
		label_10.setIcon(new ImageIcon("image\\Sample Normal Cloud.png"));
		label_10.setBounds(75, 229, 56, 29);
		label_10.setBorder(border2);
		panel_1.add(label_10);
		positons.add(label_10);
		
		JLabel label_11 = new JLabel("31");
		label_11.setIcon(new ImageIcon("image\\Sample Dark Cloud Icon.png"));
		label_11.setBounds(166, 260, 56, 29);
		label_11.setBorder(border2);
		panel_1.add(label_11);
		positons.add(label_11);
		
		JLabel label_12 = new JLabel("26");
		label_12.setIcon(new ImageIcon("image\\Sample Rain Cloud Icon .png"));
		label_12.setBounds(75, 301, 56, 29);
		label_12.setBorder(border2);
		panel_1.add(label_12);
		positons.add(label_12);
		
		JLabel label_13 = new JLabel("23");
		label_13.setIcon(new ImageIcon("image\\Sample Normal Cloud.png"));
		label_13.setBounds(166, 347, 56, 29);
		label_13.setBorder(border2);
		panel_1.add(label_13);
		positons.add(label_13);
		
		JLabel label_14 = new JLabel("21");
		label_14.setIcon(new ImageIcon("image\\Sample Normal Cloud.png"));
		label_14.setBounds(75, 392, 56, 29);
		label_14.setBorder(border2);
		panel_1.add(label_14);
		positons.add(label_14);
		
		JLabel label_16 = new JLabel("19");
		label_16.setIcon(new ImageIcon("image\\mushroom.png"));
		label_16.setBounds(75, 493, 56, 29);
		label_16.setBorder(border2);
		panel_1.add(label_16);
		positons.add(label_16);
		
		JLabel label_17 = new JLabel("20");
		label_17.setIcon(new ImageIcon("image\\9 endpoint.png"));
		label_17.setBounds(276, 435, 56, 29);
		label_17.setBorder(border2);
		panel_1.add(label_17);
		positons.add(label_17);
		
		JLabel label_18 = new JLabel("39");
		label_18.setIcon(new ImageIcon("image\\Sample Normal Cloud.png"));
		label_18.setBounds(257, 140, 56, 29);
		label_18.setBorder(border2);
		panel_1.add(label_18);
		positons.add(label_18);
		
		JLabel label_19 = new JLabel("37");
		label_19.setIcon(new ImageIcon("image\\Sample Normal Cloud.png"));
		label_19.setBounds(426, 140, 56, 29);
		label_19.setBorder(border2);
		panel_1.add(label_19);
		positons.add(label_19);
		
		JLabel label_20 = new JLabel("36");
		label_20.setIcon(new ImageIcon("image\\Sample Normal Cloud.png"));
		label_20.setBounds(337, 180, 56, 29);
		label_20.setBorder(border2);
		panel_1.add(label_20);
		positons.add(label_20);
		
		JLabel label_21 = new JLabel("35");
		label_21.setIcon(new ImageIcon("image\\Sample Dark Cloud Icon.png"));
		label_21.setBounds(520, 180, 56, 29);
		label_21.setBorder(border2);
		panel_1.add(label_21);
		positons.add(label_21);
		
		JLabel label_22 = new JLabel("33");
		label_22.setIcon(new ImageIcon("image\\Sample Safe Cloud Icon.png"));
		label_22.setBounds(257, 229, 56, 29);
		label_22.setBorder(border2);
		panel_1.add(label_22);
		positons.add(label_22);
		
		JLabel label_23 = new JLabel("32");
		label_23.setIcon(new ImageIcon("image\\Sample Normal Cloud.png"));
		label_23.setBounds(426, 229, 56, 29);
		label_23.setBorder(border2);
		panel_1.add(label_23);
		positons.add(label_23);
		
		JLabel label_24 = new JLabel("30");
		label_24.setIcon(new ImageIcon("image\\Sample Rain Cloud Icon .png"));
		label_24.setBounds(337, 260, 56, 29);
		label_24.setBorder(border2);
		panel_1.add(label_24);
		positons.add(label_24);
		
		JLabel label_25 = new JLabel("29");
		label_25.setIcon(new ImageIcon("image\\cloud-lighting.png"));
		label_25.setBounds(520, 260, 56, 29);
		label_25.setBorder(border2);
		panel_1.add(label_25);
		positons.add(label_25);
		
		JLabel label_26 = new JLabel("25");
		label_26.setIcon(new ImageIcon("image\\Sample Normal Cloud.png"));
		label_26.setBounds(337, 347, 56, 29);
		label_26.setBorder(border2);
		panel_1.add(label_26);
		positons.add(label_26);
		
		JLabel label_27 = new JLabel("28");
		label_27.setIcon(new ImageIcon("image\\Sample Normal Cloud.png"));
		label_27.setBounds(257, 301, 56, 29);
		label_27.setBorder(border2);
		panel_1.add(label_27);
		positons.add(label_27);
		
		JLabel label_28 = new JLabel("27");
		label_28.setIcon(new ImageIcon("image\\Sample Normal Cloud.png"));
		label_28.setBounds(426, 311, 56, 29);
		label_28.setBorder(border2);
		panel_1.add(label_28);
		positons.add(label_28);
		
		JLabel label_29 = new JLabel("24");
		label_29.setIcon(new ImageIcon("image\\Sample Safe Cloud Icon.png"));
		label_29.setBounds(520, 347, 56, 29);
		label_29.setBorder(border2);
		panel_1.add(label_29);
		positons.add(label_29);
		
		JLabel label_31 = new JLabel("22");
		label_31.setIcon(new ImageIcon("image\\Sample Normal Cloud.png"));
		label_31.setBounds(426, 392, 56, 29);
		label_31.setBorder(border2);
		panel_1.add(label_31);
		positons.add(label_31);
		
		JLabel label_33 = new JLabel("18");
		label_33.setIcon(new ImageIcon("image\\mushroom.png"));
		label_33.setBounds(186, 493, 56, 29);
		label_33.setBorder(border2);
		panel_1.add(label_33);
		positons.add(label_33);
		
		JLabel label_34 = new JLabel("16");
		label_34.setIcon(new ImageIcon("image\\mushroom.png"));
		label_34.setBounds(388, 493, 61, 29);
		label_34.setBorder(border2);
		panel_1.add(label_34);
		positons.add(label_34);
		
		JLabel label_35 = new JLabel("15");
		label_35.setIcon(new ImageIcon("image\\mushroom.png"));
		label_35.setBounds(509, 493, 67, 29);
		label_35.setBorder(border2);
		panel_1.add(label_35);
		positons.add(label_35);
		
		JLabel label_36 = new JLabel("17");
		label_36.setIcon(new ImageIcon("image\\mushroom.png"));
		label_36.setBounds(297, 537, 56, 29);
		label_36.setBorder(border2);
		panel_1.add(label_36);
		positons.add(label_36);
		
		JLabel label_37 = new JLabel("14");
		label_37.setIcon(new ImageIcon("image\\mushroom.png"));
		label_37.setBounds(75, 574, 56, 29);
		label_37.setBorder(border2);
		panel_1.add(label_37);
		positons.add(label_37);
		
		JLabel label_38 = new JLabel("13");
		label_38.setIcon(new ImageIcon("image\\mushroom.png"));
		label_38.setBounds(186, 579, 56, 29);
		label_38.setBorder(border2);
		panel_1.add(label_38);
		positons.add(label_38);
		
		JLabel label_39 = new JLabel("12");
		label_39.setIcon(new ImageIcon("image\\mushroom.png"));
		label_39.setBounds(388, 574, 61, 29);
		label_39.setBorder(border2);
		panel_1.add(label_39);
		positons.add(label_39);
		
		JLabel label_40 = new JLabel("11");
		label_40.setIcon(new ImageIcon("image\\mushroom.png"));
		label_40.setBounds(509, 574, 67, 29);
		label_40.setBorder(border2);
		panel_1.add(label_40);
		positons.add(label_40);
		
		
		JPanel panel_2 = new JPanel();
		panel_2.setBorder(new LineBorder(Color.ORANGE));
		panel_2.setBounds(0, 0, 73, 258);
		panel_1.add(panel_2);
		panel_2.setLayout(null);
		
		
		JLabel lblNewLabel_1 = new JLabel("click button to move");
		lblNewLabel_1.setBounds(-1, 6, 75, 18);
		panel_2.add(lblNewLabel_1);
		
		Border border3 = new LineBorder(Color.YELLOW, 2);
		//move Label
		JLabel[] moveLabels = new JLabel[4];
		JLabel label_15 = new JLabel("");
		label_15.setBounds(-1, 37, 60, 35);
		label_15.setBorder(border3);
		panel_2.add(label_15);
		moveLabels[0] = label_15;
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(-1, 100, 57, 35);
		lblNewLabel_2.setBorder(border3);
		panel_2.add(lblNewLabel_2);
		moveLabels[1] = lblNewLabel_2;
		
		JLabel label_30 = new JLabel("");
		label_30.setBounds(-1, 158, 57, 35);
		label_30.setBorder(border3);
		panel_2.add(label_30);
		moveLabels[2] = label_30;
		
		JLabel label_32 = new JLabel("");
		label_32.setBounds(-1, 223, 60, 35);
		label_32.setBorder(border3);
		panel_2.add(label_32);
		moveLabels[3] = label_32;
		
		JPanel panel_3 = new JPanel();
		panel_3.setBorder(new LineBorder(Color.YELLOW));
		panel_3.setBounds(0, 307, 73, 98);
		panel_1.add(panel_3);
		panel_3.setLayout(null);
		
		
		
		
		JLabel label_42 = new JLabel("score");
		label_42.setBackground(Color.RED);
		label_42.setBounds(1, 56, 58, 18);
		panel_3.add(label_42);
		
		JLabel label_41 = new JLabel("roll the dice");
		label_41.setBackground(new Color(255, 153, 102));
		label_41.setBorder(border3);
		label_41.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				isRoll = true;
				score = new Random().nextInt(10) + 1;
				label_42.setText("score:"+score );
			}
		});
		label_41.setBounds(1, 13, 72, 30);
		panel_3.add(label_41);
		
		JLabel lblNewLabel_3 = new JLabel("player1name:");
		lblNewLabel_3.setBounds(620, 62, 99, 33);
		getContentPane().add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setBounds(729, 66, 86, 24);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblPlayername = new JLabel("player2name:");
		lblPlayername.setBounds(620, 343, 99, 33);
		getContentPane().add(lblPlayername);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(733, 347, 86, 24);
		getContentPane().add(textField_1);
		
		JLabel lblNewLabel_4 = new JLabel("winner:");
		lblNewLabel_4.setBounds(643, 615, 72, 18);
		getContentPane().add(lblNewLabel_4);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(729, 612, 86, 24);
		getContentPane().add(textField_2);
		
		user1Tril = new JTextArea(10,20);
		user1Tril.setLineWrap(true);
		user1Tril.setText("");
		user1Tril.setBounds(620, 103, 195, 195);
		getContentPane().add(user1Tril);
		user1Tril.setColumns(10);
		
		user2Tril = new JTextArea(10,20);
		user1Tril.setLineWrap(true);
		user2Tril.setText("");
		user2Tril.setBounds(620, 389, 195, 183);
		getContentPane().add(user2Tril);
		user2Tril.setColumns(10);
		
		
		
		//choose which alien to move according to Label
		for(JLabel move : moveLabels) {
			move.setBorder(border3);
			move.addMouseListener(new MouseAdapter()
			{
				public void mouseClicked(MouseEvent argo) {
					
					for(Alien alien : gameAliens) {
						if(alien.getIcon() == move.getIcon()) {
							moveAlien = alien;
							System.out.println("tongguo biaoqianxuanze");
							moveSelectedAlien(null);
						}
					}
					
				}
			});
		}
		
		for(JLabel pos : positons) {
			pos.addMouseListener(new MouseAdapter()
			{
				public void mouseClicked(MouseEvent argo) {
					moveSelectedAlien(pos);
//					//if do not roll dice,then do nothing
//					if(!isRoll) {
//						return;
//					}
//					
//					
//					//judge which alien be chosen.
                                        //two methods:clicking map || clicking left icons
//					if(pos != null) {//if click map，create a local moveAlien,cover the global moveAlien.
                                                          //that is, subject the map.
//						moveAlien = null;
//						for(Alien alien : gameAliens) {
//							if(pos.getIcon() == alien.getIcon()) {
//								moveAlien = alien;
//								System.out.println("_____________________________" + moveAlien.getIcon());
//							}
//						}
//					}else {//click icon,but also need to obtain the corresponding position Label of current icons
//						pos = Tool.findPosLabel(moveAlien.getPositionName(), positons);
//					}
//					
//					
//					if(moveAlien == null) {	//click map,but there is no aliens, then do nothing
//						return ;
//					}
//					
//					
//					if(!(moveAlien.getUserOrder() == turn)) {//if click alien who cannot move,then do nothing
//						return;
//					}
//					
//					if(dark.get(moveAlien) > 1) {//if click alien who are frozen,then do nothing
//						return;
//					}
//					
//					
//					//-------------------------------------------------if not in above situations,can move normally
//					
//					//turn
//					turn = (turn == 1 ? 2 : 1);
//					
//					//sub 1 for other aliens' freezing period
//					for(Alien alien : gameAliens) {
//						if(dark.get(alien) > 1) {
//							dark.put(alien, dark.get(alien) - 1);
//						}
//					}
//					
//					
//					String dest ;
//					//set new cloud for alien
//					if(Tool.moveBack(pos)) {
//						dest = String.valueOf(Integer.parseInt(moveAlien.getPositionName()) - score);
//					}else {
//						dest = String.valueOf(Integer.parseInt(moveAlien.getPositionName()) + score);
//					}
//					
//					//move alien
//					
//					System.out.println(startLables[0].getIcon());
//					System.out.println(positons.size());
//					Tool.moveTo(moveAlien, dest, lastIcon, positons);
//					System.out.println(startLables[0].getIcon());
//					Tool.check(moveAlien, lastIcon, positons, gameAliens, dark);
//				
				}
			});
		}
		
//		ImageIcon icon1 = new ImageIcon("image\\alien1.png"); 
//		ImageIcon icon2 = new ImageIcon("image\\alien2.png"); 
//		ImageIcon icon3 = new ImageIcon("image\\alien3.png"); 
//		ImageIcon icon4 = new ImageIcon("image\\alien4.png"); 
//		
//		gameAliens[0] = new Alien(1, 1, icon1);
//		gameAliens[1] = new Alien(1, 2, icon2);
//		gameAliens[2] = new Alien(2, 3, icon3);
//		gameAliens[3] = new Alien(2, 4, icon4);
		
		//set initial Label for alien,in order to return
		for(int i = 0; i < 4; i++) {
			System.out.println("The" + i + "th alien icon is" +   gameAliens[i].getIcon());
			startLables[i].setIcon(gameAliens[i].getIcon());
			gameAliens[i].setStartPos(startLables[i]);
			dark.put(gameAliens[i], 0);
			lastIcon.put(gameAliens[i], null);
			
			//moveLabel bounded to aliens
			moveLabels[i].setIcon(gameAliens[i].getIcon());
		}
		
		//set 2 textfield for user name
		textField.setText(users[0].getName());
		textField_1.setText(users[1].getName());
		
		//initialise coexist
		for(JLabel pos : positons) {
			coexist.put(pos, new ArrayList<>());
		}
		
	}
	
	//move alien
	public void moveSelectedAlien(JLabel pos) {
		//if do not roll dice,do nothing
		if(!isRoll) {
			return;
		}
		
		//if score illegal,do nothing
		if(score < 1 || score > 10) {
			return ;
		}
		
		
		//judge which alien be chosen.2 methods: click map or left icons
		if(pos != null) {//if click map，create a local moveAlien,cover the global moveAlien.
		                    //that is, subject the map.
			moveAlien = null;
			for(Alien alien : gameAliens) {
				if(pos.getIcon() == alien.getIcon()) {
					moveAlien = alien;
				}
			}
		}else {//click icon,but also need to obtain the corresponding position Label of current icons
			pos = Tool.findPosLabel(moveAlien.getPositionName(), positons);
		}
		
		
		if(moveAlien == null) {	//click map,but there is no aliens, then do nothing
			return ;
		}
		
		
		if(!(moveAlien.getUserOrder() == turn)) {//if click alien who cannot move,then do nothing
			return;
		}
		
		if(dark.get(moveAlien) > 0) {//if click alien who are frozen,then do nothing
			return;
		}
		
		
		//-------------------------------------------------if not in above situations,can move normally
		
		
		//wait for next turn to roll dice
		isRoll = false;
		
		//real score to move
		realScore = score;
		
		if(turn == 1) {
			user1Tril.setText(user1Tril.getText()+ realScore + "->");
			turn = 2;
		}else if(turn == 2) {
			user2Tril.setText( user2Tril.getText()+ realScore + "->");
			turn = 1;
		}
		
		//sub 1 for other aliens' freezing period
		for(Alien alien : gameAliens) {
			if(dark.get(alien) > 0) {
				dark.put(alien, dark.get(alien) - 1);
			}
		}
		
		System.out.println("frozen times for alien1" + dark.get(gameAliens[0]));
		
		String dest ;
		//set new cloud for alien
		if(Tool.moveBack(pos)) {
			dest = String.valueOf(Integer.parseInt(moveAlien.getPositionName()) - score);
		}else {
			dest = String.valueOf(Integer.parseInt(moveAlien.getPositionName()) + score);
		}
		
		
		
		//move alien
		
		System.out.println(startLables[0].getIcon());
		System.out.println(positons.size());
		Tool.moveTo(moveAlien, dest, lastIcon, positons, coexist);
		
		System.out.println("alien"+ moveAlien.getNumber() + "move" + score);
		Tool.check(moveAlien, lastIcon, positons, gameAliens, dark, coexist);
		if(moveAlien.getPositionName().equals("20")) {
			if(turn == 2 ) {//user 1 get to end point in last step
				textField_2.setText(users[0].getName());
			}else {//user 2 get to end point in next step
				textField_2.setText(users[1].getName());
			}
		}
		
	}
	

}
